/*
// alternative way
fun getConversionLambda(str: String): (Double) -> Double {
    if (str == "CentigradeToFahrenheit") return {it *1.8 + 32}
    else if (str == "KgsToPounds") return {it * 2.204623}
    else if (str == "PoundsToUSTons") return {it / 2000.0}
    else return {it}
}
*/

/*
// alternative way
// In this function, the curly braces is defining scope for "when"
fun getConversionLambda(str: String): (Double) -> Double =
    when (str) {
        "CelsiusToFahrenheit" -> {c -> c * 1.8 + 32}
        "KgsToPounds" -> { c -> c * 2.204623 }
        "PoundsToUSTons" -> { c -> c / 2000.0 }
        else -> { c -> c }
    }
*/
/*
// alternative way
// In this function, the outer curly braces is defining lambda function
// (note that curly braces can mean two different things in Kotlin).
// Since the whole thing is a lambda, "it" is defined in the second function.
// we can use "it" if each lambda uses a single parameter whose type the compiler can infer
fun getConversionLambda(str: String): (Double) -> Double {
     when(str) {
         "CelsiusToFahrenheit" -> return {it * 1.8 + 32.0}
         "KgsToPounds" -> return {it * 2.204623}
         "PoundsToUSTons" -> return {it / 2000.0}
         else -> return {it}
     }
}
*/

// Better way
// A function can return a lambda
fun getConversionLambda(str: String): (Double) -> Double = {
    when(str){
        "CelsiusToFahrenheit" -> it * 1.8 + 32.0
        "KgsToPounds" -> it * 2.204623
        "PoundsToTons" -> it / 2000.0
        else -> it
    }
}

typealias DoubleConversion = (Double) -> Double

fun convert3 (x: Double, converter: DoubleConversion): Double{
    val result = converter(x)
    println("function convert3: $x is converted to $result")
    return result
}
fun combine(lambda1: DoubleConversion, lambda2: DoubleConversion): DoubleConversion{
    return { x:Double -> lambda2(lambda1(x)) }
}

fun main(){
    // convert 2.5 kg to Pounds
    // You can invoke the lambda returned by a function, or
    // use it as an argument for another function
    // println("Convert 2.5 kg to Pounds: ${getConversionLambda("KgsToPounds").invoke(2.5)}")
    println("Convert 2.5kg to Pounds: ${getConversionLambda("KgsToPounds")(2.5)}\n")

    // define two conversion lambda
    val kgsToPoundsLambda = getConversionLambda("KgsToPounds")
    val poundsToTonsLambda = getConversionLambda("PoundsToTons")

    // combine the two lambdas to create a new one
    // returned function: lambda2(lambda1(x)) == poundsToTonsLambda(kgsToPoundsLambda(x))
    val kgsToTonsLambda = combine(kgsToPoundsLambda, poundsToTonsLambda)

    // Use the new lambda to convert 17.4 KG to Tons
    // 17.4 * 2.204623 / 2000.0
    // Pay attention to printing order: evaluate convert3 first and the println
    val value = 17.4
    println("$value kgs is ${convert3(value, kgsToTonsLambda)} Tons")
}