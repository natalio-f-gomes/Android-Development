class Dog (val name:String, theWeight: Int, theBreed:String) {
    // Defining properties in the main body of the class
    // gives flexibility than adding them at the constructor
    var activities = arrayOf("Sleep")

    // breed will automatically create getter()
    private val breed = theBreed.uppercase()

    // Initializer blocks
    // need more complex than a simple expression
    // Or there's extra code you want to run when each object is created
    // It will be executed when the object is initialized,
    // immediately after the constructor is called
    init {
        println("Dog $name has been created")
    }
    // Your class can have multiple initializer blocks.
    // Each one runs in the order in which it appears in the class body
    // But avoid more than one init block if you can, for performance point of view
    init {
        println("The breed is $breed")
    }

    // custom setter()
    // Add a custom setter to the weight property
    // A setter has one parameter
    var weight = theWeight
        set(value){
            // The setter updates the value of the weight property
            // by means of the field identifier. "field" refers to the property
            if (value > 0) field=value  // will be updated
            // DON'T DO THIS: Infinite loop by calling setter again...
            // weight=value

        }
    // custom getter()
    // add it to the property by writing it immediately below the property declaration
    // return type must match that of the property whose value you want to return
    // weightInKgs is public property
    val weightInKgs:Double
        get()=weight / 2.2  // defines getter()

    // member function or method
    fun bark() {
        println(if (weight < 20) "Yip!" else "Woof")
    }
}

fun main() {
    // create a Dog object. It looks like we're calling a function name Dog,
    // but, we're calling the Dog constructor
    val myDog = Dog("Fido", 70, "Mixed")
    myDog.bark()        // user-defined method
    println()

    // to access properties and functions
    println(myDog.name) // getter()
    myDog.weight = 75   // setter(), only for var
    println("Weight in Kgs is ${myDog.weightInKgs}")    // 75/2.2

    myDog.weight = -2
    println("Weight is ${myDog.weight}\n")    // not modified since <0

    myDog.activities = arrayOf("Walks", "Fetching balls", "Frisbee")
    for (item in myDog.activities){
        println("My dog enjoys $item")
    }
    println()
    // creates two Dog object,
    // and adds them to an array<Dog>, named dogs
    val dogs = arrayOf(Dog("Fido", 70, "Mixed"),
                       Dog("Ripper",10,"Poodle"))
    dogs[1].weight=15
    dogs[1].bark()
}
