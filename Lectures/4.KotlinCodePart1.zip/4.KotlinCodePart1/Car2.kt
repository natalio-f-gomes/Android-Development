import java.lang.RuntimeException

// What if someone sets color to an empty string? car.color=""
// theColor will not be given a value through the constructor
// Let's modify Car class to avoid car.color=""

// yearOfMake: property (instance variable) - getter & setter will be created
// theColor: parameter variable (not an instance variable) - getter & setter will NOT be created
class Car2 (val yearOfMake: Int,  theColor: String) {
    var fuelLevel = 100     // fuelLevel is property

    // color is property  Java: this.color = theColor
    // this is custom setter. A setter has one parameter - proposed new value
    var color = theColor
        set (value){
            if (value.isBlank()){
                throw RuntimeException("no empty, please")
            }
            // The setter updates the value of the color property
            // by means of the field identifier. "field" refers to the property
            field = value
            // DON'T DO THIS: Infinite loop by calling setter again...
            // color = value
        }
}

fun main(){
    val car2 = Car2(2023, "Red")
    car2.color = "Green"    // color is property
    car2.fuelLevel--        // fuelLevel is property
    println(car2.fuelLevel)
    //println(car2.theColor)    // ERROR. Why?

    try {
        car2.color = ""
    } catch (ex: Exception){
        println(ex.message) // Java: getMessage()
    }
    println(car2.color)
}