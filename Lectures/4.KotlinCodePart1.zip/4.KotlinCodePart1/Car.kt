// The Kotlin compiler wrote a constructor, defined a property,
// and added a getter to retrieve the value of that property.
// by default, the access to the class and its members is public
// constructor--> (val yearOfMake: Int, var color: String)
class Car (val yearOfMake: Int, var color: String)

fun main(){
    println(useCarObject())
}

fun useCarObject(): Pair<Int,String>{
    // creating an instance by calling constructor
    // class name should start with uppercase (lower case works, but not a good idea)
    val car = Car(2023, "Red")
    val year = car.yearOfMake   // calling getter --> car.getYearOfMake()
    car.color = "Green"         // calling setter --> car.setColor()
    //car.color = ""         // calling setter --> car.setColor()
    return year to car.color    // note Type Pair<Int,String>
}